package com.assignment.Order;




import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.Order.Client.OrderItemClient;
import com.assignment.Order.model.Order;
import com.assignment.Order.model.OrderItem;
import com.assignment.Order.service.OrderService;
import com.assignment.Order.exception.OrderNotFoundException;

@RestController
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	@Autowired
	OrderItemClient  oiClient;
	
	//To fetch all order details
	@GetMapping("/allOrders")
	public List<Order>  getAllOrders() {
		
		List<Order> lo =  orderService.getAllOrders();
		List<OrderItem> loi =null;
		for(int i=0;i<lo.size();i++) {
		 loi=  oiClient.getOrderItemsbyOrder(lo.get(i).getOrder_id());  
		 lo.get(i).setOrderItem(loi);
		}
	
		
		return lo ;
	}
	
	//To fetch order by orderId 
	@GetMapping("/Order/{orderCode}")
	public Order getOrderBy(@PathVariable int orderCode)
	{
	Optional<Order> order =orderService.getOrderById(orderCode);
	System.out.println( "order >>> "+order);	
	   if(!order.isPresent())
		{  
		System.out.println(" got empty order");
					throw new OrderNotFoundException("id>>> "+orderCode);
		}
	   else {
		   List<OrderItem> loi =oiClient.getOrderItemsbyOrder(order.get().getOrder_id());  
			 order.get().setOrderItem(loi);
			
		   
	   }
	   return order.get();
	}
	
	//to fetch OrderItems by orderId  from OrderItem Service
	@GetMapping("/Order/{order_id}/OrderItem")
	public List<OrderItem> getOrderbyOrderItem(@PathVariable int order_id)
	{
		
		return oiClient.getOrderItemsbyOrder(order_id);
	}
	
	
	//To fetch all OrderItem details from OrderItem Service
	@GetMapping("/OrderItem/fetchAll")
	public  List<OrderItem>   getAllOrderItems()
	{
		return  oiClient.getallOrderItem();
	}
	
	
	//To add Order to Order Service
	@PostMapping("/Order/add")
	public int  createOrder(@RequestBody Order order) //throws ConstraintViolationException
	{
		
		return orderService.createOrder(order);
	}
	
	
	//To add OrderItem to OrderItem service
	@PostMapping("/OrderItem/add")
	public int createOrderItem(@RequestBody OrderItem orderItem)
	{
		return oiClient.createOrderItem(orderItem);
		}
	
	
	
	

}
