package com.assignment.Order.repository;

import org.springframework.data.repository.CrudRepository;

import com.assignment.Order.model.Order;

public interface OrderRepository extends CrudRepository<Order,Integer> {
	

}
