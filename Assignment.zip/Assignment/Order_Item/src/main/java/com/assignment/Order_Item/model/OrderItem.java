package com.assignment.Order_Item.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ASS_ORDER_ITEM")
public class OrderItem {
	
	
	public OrderItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column
	private int order_code;
	
	@Column
	private String order_name;
	
	@Column
	private int quantity;
	
	@Column
	private int order_id;
	


	public OrderItem(int order_code, String order_name, int quantity, int order_id) {
		super();
		this.order_code = order_code;
		this.order_name = order_name;
		this.quantity = quantity;
		this.order_id = order_id;
	}

	public int getOrder_code() {
		return order_code;
	}

	public void setOrder_code(int order_code) {
		this.order_code = order_code;
	}

	public String getOrder_name() {
		return order_name;
	}

	public void setOrder_name(String order_name) {
		this.order_name = order_name;
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	

	

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
