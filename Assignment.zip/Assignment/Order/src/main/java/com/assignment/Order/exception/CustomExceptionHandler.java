package com.assignment.Order.exception;


import java.util.Date;


import javax.validation.ConstraintViolationException;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.assignment.Order.exception.ExceptionResponse;
import com.assignment.Order.exception.OrderNotFoundException;

@ControllerAdvice
public class CustomExceptionHandler  extends ResponseEntityExceptionHandler{
	
	
	@ExceptionHandler(Exception.class)  
	//override method of ResponseEntityExceptionHandler class  
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request)  
	{  
	//creating exception response structure
		String message = ex.getMessage();
	Throwable cause,resultCause = ex;
	while((cause = resultCause.getCause()) !=null && resultCause != cause)
	{
		resultCause = cause;
	}
	if(resultCause instanceof ConstraintViolationException)
	{
		message =(((ConstraintViolationException)resultCause).getConstraintViolations()).iterator().next().getMessage();
	}else
	{
		message = resultCause.getMessage();
//		resultCause.printStackTrace();
//		message = "Unknown Error";
	}
		
	ExceptionResponse exceptionResponse= new ExceptionResponse(new Date(), "Exception from RestFul Service is "+message, request.getDescription(false));  
	//returning exception structure and Internal Server status   
	return new ResponseEntity<Object>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);  
	}  

	
	@ExceptionHandler(OrderNotFoundException.class)  
	//override method of ResponseEntityExceptionHandler class  
	public final ResponseEntity<Object> handleOrderNotFoundExceptions(OrderNotFoundException ex, WebRequest request)  
	{  
	//creating exception response structure  
	ExceptionResponse exceptionResponse= new ExceptionResponse(new Date(),"Exception ONF from Restful Service is "+ex.getMessage(), request.getDescription(false));  
	//returning exception structure and Not Found status   
	return new ResponseEntity<Object>(exceptionResponse, HttpStatus.NOT_FOUND);  
	}  
	
	
	

}
