package com.assignment.Order_Item;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.Order_Item.model.OrderItem;
import com.assignment.Order_Item.service.OrderItemService;

@RestController
public class OrderItemController {
	
	@Autowired
	OrderItemService  oiService;

     //To  fetch Order Item details by  filtering  ordercode	
	@GetMapping("/OrderItem/{ocode}")
	public  OrderItem  getOrderItembyCode(@PathVariable int ocode)
	{
		return oiService.getOrderItemBycode(ocode);
	}
	
	
	//To fetch all OrderItem details
	@GetMapping("/OrderItem/fetchAll")
	public List<OrderItem> getallOrderItem()
	{
		return oiService.getallItemOrder();
	}
	
	//To Create new OrderItem 
	@PostMapping("/OrderItem/add")
	public int createOrderItem(@RequestBody OrderItem orderItem)
	{
		return oiService.createOrderItem(orderItem);
	}
	
	//To fetch  OrderItem by filtering  order id
	@GetMapping("/Order/{id}/OrderItem")
	public List<OrderItem> getOrderItemsbyOrder(@PathVariable int id)
	{
		System.out.println(" inside Controller .. "+id);
		return oiService.getOrderItembyOrderId(id);
	}
	
 
}
