package com.assignment.Order_Item.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.assignment.Order_Item.model.OrderItem;

@Repository
public interface OrderItemRespository extends JpaRepository<OrderItem, Integer> {

}
