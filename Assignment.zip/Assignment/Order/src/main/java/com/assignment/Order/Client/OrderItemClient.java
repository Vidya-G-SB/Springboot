package com.assignment.Order.Client;

import java.util.List;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.assignment.Order.model.OrderItem;

@FeignClient(name="Order-Item")
public interface OrderItemClient {
	
	@GetMapping("/OrderItem/{ocode}")
	  OrderItem  getOrderItembyCode(@PathVariable int ocode);
	
	
	@GetMapping("/Order/{id}/OrderItem")
	List<OrderItem> getOrderItemsbyOrder(@PathVariable int id);
	
	@GetMapping("/OrderItem/fetchAll")
	 List<OrderItem> getallOrderItem();
	
	
	
	@PostMapping("/OrderItem/add")
	 int createOrderItem(@RequestBody OrderItem orderItem);
	
	
	
	

}
