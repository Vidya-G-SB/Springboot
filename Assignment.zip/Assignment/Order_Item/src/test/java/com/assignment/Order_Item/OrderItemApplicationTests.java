package com.assignment.Order_Item;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderItemApplicationTests {

	@Test
	void contextLoads() {
	}

}
