package com.assignment.Order.model;



import java.time.LocalDate;
import java.util.List;

import javax.annotation.Nonnull;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.FutureOrPresent;

import javax.validation.constraints.Size;


import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;



@Entity
@Table(name="ASS_ORDER")
public class Order {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private int order_id;
	
	@Nonnull
    @Size(max=50)
	@Column
	private String customer_name;
	
	






	@Column
	private String shipping_address;
	
	@DateTimeFormat(iso = ISO.DATE)
	@FutureOrPresent(message="Past date is not allowed")
	@Column
	private LocalDate order_date;
	
	
	
	@Column
	private int Total;
	
	
	public List<OrderItem> getOrderItem() {
		return orderItem;
	}



	public void setOrderItem(List<OrderItem> orderItem) {
		this.orderItem = orderItem;
	}







	public Order(int order_id, @Size(max = 50) String customer_name, String shipping_address,
			@FutureOrPresent LocalDate order_date, int total) {
		super();
		this.order_id = order_id;
		this.customer_name = customer_name;
		this.shipping_address = shipping_address;
		this.order_date = order_date;
		Total = total;
	}







	@OneToMany(mappedBy = "order_id")
	private List<OrderItem>   orderItem;
	
	
	
	





	



	


	


	public LocalDate getOrder_date() {
		return order_date;
	}



	public void setOrder_date(LocalDate order_date) {
		this.order_date = order_date;
	}



	public int getOrder_id() {
		return order_id;
	}



	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}



	



	public String getCustomer_name() {
		return customer_name;
	}



	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}



	public String getShipping_address() {
		return shipping_address;
	}



	public void setShipping_address(String shipping_address) {
		this.shipping_address = shipping_address;
	}



	public int getTotal() {
		return Total;
	}



	public void setTotal(int total) {
		Total = total;
	}






	
		public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
