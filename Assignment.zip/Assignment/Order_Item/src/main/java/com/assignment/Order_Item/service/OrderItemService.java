package com.assignment.Order_Item.service;

import java.util.List;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.Order_Item.model.OrderItem;
import com.assignment.Order_Item.repository.OrderItemRespository;

@Service
public class OrderItemService {
	
	@Autowired
	OrderItemRespository   oiRepository;
	
	public OrderItem getOrderItemBycode(int pcode)
	{
		return  oiRepository.findById(pcode).get();
	}
	
	
	
	
	public  int  createOrderItem(OrderItem orderItem)
	{
		 oiRepository.save(orderItem);
		 
		 return orderItem.getOrder_code();
	}
	
	
	public List<OrderItem>    getallItemOrder()
	{
		return  (List<OrderItem>) oiRepository.findAll();
	}
	
	
	public List<OrderItem>  getOrderItembyOrderId(int oid)
	{

		System.out.println(" inside Service "+oid);
		System.out.println(" compare .. "+oiRepository.findAll().stream().filter(orderItem -> orderItem.getOrder_id() == oid));
	return	  oiRepository.findAll().stream().filter(orderItem -> orderItem.getOrder_id() == oid).collect(Collectors.toList());
		
		
	}
	
	

}
